"""SQL adapter, SQLAlchemy Core only, same conventions as
capabilities/party_identity/adapters/sql.py: app-generated UUID keys, no
FK-constraint reliance, no autoincrement.

`close_with_record` is the one place this app currently needs a real
multi-table transaction (Assignment.state + ClosureRecord in one commit).
Postgres gives us that for free — take it while we have it. If this ever
moves to an Iceberg-backed adapter, this method is the one that would need
redesigning (e.g. via the outbox pattern), not the rest of the package.

`update`/`close_with_record` enforce optimistic concurrency: the WHERE
clause matches on `version` as well as `id`, so a write against a stale
copy affects zero rows — the code below distinguishes "no such row"
(AssignmentNotFound) from "row exists but version moved"
(ConcurrentModification) with one extra SELECT inside the same
transaction.
"""
from __future__ import annotations

from datetime import date
from typing import Optional
from uuid import UUID

from sqlalchemy import (
    JSON,
    Column,
    Connection,
    Date,
    DateTime,
    Engine,
    Float,
    Integer,
    MetaData,
    String,
    Table,
    Text,
    inspect,
    insert,
    select,
    text,
    update,
)

from ..clock import today
from ..domain import (
    Assignment,
    AssignmentKind,
    AssignmentNotFound,
    AssignmentState,
    ChangeRequest,
    ClosureRecord,
    ConcurrentModification,
    GoalSetting,
    RequestStatus,
    RequestType,
    ReverseFeedback,
    ReviewScore,
)

metadata = MetaData()

assignments_table = Table(
    "assignments",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("agent_id", String(36), nullable=False, index=True),
    Column("manager_id", String(36), nullable=False, index=True),
    Column("start_date", Date, nullable=False),
    Column("end_date", Date, nullable=True),
    Column("state", String(32), nullable=False),
    Column("kind", String(16), nullable=False),
    Column("closed_reason", String(32), nullable=True),
    Column("closure_note", Text, nullable=True),
    Column("version", Integer, nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False),
)

goal_settings_table = Table(
    "goal_settings",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("assignment_id", String(36), nullable=False, unique=True, index=True),
    Column("goals", Text, nullable=False),
    Column("criteria", JSON, nullable=False, default=list),
    Column("set_at", DateTime(timezone=True), nullable=False),
    Column("frozen", Integer, nullable=False),
    Column("agreed_by", String(36), nullable=True),
    Column("agreed_at", DateTime(timezone=True), nullable=True),
)

review_scores_table = Table(
    "review_scores",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("assignment_id", String(36), nullable=False, unique=True, index=True),
    Column("criterion_scores", JSON, nullable=False),
    Column("objective_score", Float, nullable=False),
    Column("notes", Text, nullable=False),
    Column("submitted_by", String(36), nullable=True),
    Column("submitted_at", DateTime(timezone=True), nullable=False),
    Column("frozen", Integer, nullable=False),
)

change_requests_table = Table(
    "change_requests",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("assignment_id", String(36), nullable=False, index=True),
    Column("request_type", String(16), nullable=False),
    Column("requested_by", String(36), nullable=False),
    Column("new_end_date", Date, nullable=True),
    Column("notes", Text, nullable=False),
    Column("status", String(16), nullable=False),
    Column("requested_at", DateTime(timezone=True), nullable=False),
    Column("decided_by", String(36), nullable=True),
    Column("decided_at", DateTime(timezone=True), nullable=True),
)

closure_records_table = Table(
    "closure_records",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("assignment_id", String(36), nullable=False, unique=True, index=True),
    Column("objective_score", Float, nullable=False),
    Column("subjective_notes", Text, nullable=False),
    Column("recorded_at", DateTime(timezone=True), nullable=False),
)

reverse_feedback_table = Table(
    "reverse_feedback",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("assignment_id", String(36), nullable=False, index=True),
    Column("notes", Text, nullable=False),
    Column("recorded_at", DateTime(timezone=True), nullable=False),
)


def _ensure_columns(engine: Engine, table: Table, backfill: Optional[dict] = None) -> None:
    """Additive-only schema patch for tables that already existed on disk
    before a column was added to this module's table definitions.

    `metadata.create_all()` only creates missing *tables* -- it never adds
    missing *columns* to a table that already exists. Without this, an
    older local/dev database file (created before, say, `criteria` or
    `version` existed) breaks every query against the new column with a
    raw `OperationalError` instead of self-healing. Not a real migration
    framework -- revisit with Alembic if schema evolution outgrows this.
    """
    inspector = inspect(engine)
    if table.name not in inspector.get_table_names():
        return
    existing = {col["name"] for col in inspector.get_columns(table.name)}
    missing = [column for column in table.columns if column.name not in existing]
    if not missing:
        return
    backfill = backfill or {}
    with engine.begin() as conn:
        for column in missing:
            col_type = column.type.compile(dialect=engine.dialect)
            conn.execute(text(f"ALTER TABLE {table.name} ADD COLUMN {column.name} {col_type}"))
            if column.name in backfill:
                conn.execute(update(table).values(**{column.name: backfill[column.name]}))


def create_schema(engine: Engine) -> None:
    metadata.create_all(
        engine,
        tables=[
            assignments_table,
            goal_settings_table,
            closure_records_table,
            reverse_feedback_table,
            review_scores_table,
            change_requests_table,
        ],
    )
    _ensure_columns(
        engine, assignments_table, backfill={"version": 0, "kind": AssignmentKind.PRIMARY.value}
    )
    _ensure_columns(
        engine,
        goal_settings_table,
        backfill={"criteria": [], "frozen": 0, "agreed_by": None, "agreed_at": None},
    )


class SqlAssignmentRepo:
    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    def add(self, assignment: Assignment) -> None:
        with self._engine.begin() as conn:
            conn.execute(insert(assignments_table).values(**_assignment_values(assignment)))

    def get(self, assignment_id: UUID) -> Assignment:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(assignments_table).where(assignments_table.c.id == str(assignment_id))
            ).mappings().first()
        if row is None:
            raise AssignmentNotFound(assignment_id)
        return _row_to_assignment(row)

    def _write(self, conn: Connection, assignment: Assignment) -> None:
        result = conn.execute(
            update(assignments_table)
            .where(assignments_table.c.id == str(assignment.id))
            .where(assignments_table.c.version == assignment.version)
            .values(**_assignment_values(assignment, include_id=False, bump_version=True))
        )
        if result.rowcount == 0:
            exists = conn.execute(
                select(assignments_table.c.id).where(
                    assignments_table.c.id == str(assignment.id)
                )
            ).first()
            if exists is None:
                raise AssignmentNotFound(assignment.id)
            raise ConcurrentModification(assignment.id)

    def update(self, assignment: Assignment) -> None:
        with self._engine.begin() as conn:
            self._write(conn, assignment)

    def close_with_record(self, assignment: Assignment, closure: ClosureRecord) -> None:
        with self._engine.begin() as conn:
            self._write(conn, assignment)
            conn.execute(
                insert(closure_records_table).values(
                    id=str(closure.id),
                    assignment_id=str(closure.assignment_id),
                    objective_score=closure.objective_score,
                    subjective_notes=closure.subjective_notes,
                    recorded_at=closure.recorded_at,
                )
            )

    def list_all(self) -> list[Assignment]:
        with self._engine.connect() as conn:
            rows = conn.execute(select(assignments_table)).mappings().all()
        return [_row_to_assignment(r) for r in rows]

    def list_by_agent(self, agent_id: UUID) -> list[Assignment]:
        with self._engine.connect() as conn:
            rows = conn.execute(
                select(assignments_table).where(assignments_table.c.agent_id == str(agent_id))
            ).mappings().all()
        return [_row_to_assignment(r) for r in rows]

    def list_by_manager(self, manager_id: UUID) -> list[Assignment]:
        with self._engine.connect() as conn:
            rows = conn.execute(
                select(assignments_table).where(
                    assignments_table.c.manager_id == str(manager_id)
                )
            ).mappings().all()
        return [_row_to_assignment(r) for r in rows]

    def list_active_without_goal_setting(
        self, older_than_days: int, as_of: Optional[date] = None
    ) -> list[Assignment]:
        as_of = as_of or today()
        with self._engine.connect() as conn:
            goal_set_ids = {
                r[0]
                for r in conn.execute(select(goal_settings_table.c.assignment_id))
            }
            rows = conn.execute(
                select(assignments_table).where(
                    assignments_table.c.state == AssignmentState.ACTIVE.value
                )
            ).mappings().all()
        result = []
        for row in rows:
            if row["id"] in goal_set_ids:
                continue
            assignment = _row_to_assignment(row)
            if (as_of - assignment.start_date).days >= older_than_days:
                result.append(assignment)
        return result

    def list_active_older_than(
        self, older_than_days: int, as_of: Optional[date] = None
    ) -> list[Assignment]:
        as_of = as_of or today()
        with self._engine.connect() as conn:
            rows = conn.execute(
                select(assignments_table).where(
                    assignments_table.c.state == AssignmentState.ACTIVE.value
                )
            ).mappings().all()
        return [
            a
            for a in (_row_to_assignment(row) for row in rows)
            if (as_of - a.start_date).days >= older_than_days
        ]

    def add_goal_setting(self, goal_setting: GoalSetting) -> None:
        with self._engine.begin() as conn:
            conn.execute(
                insert(goal_settings_table).values(**_goal_setting_values(goal_setting))
            )

    def update_goal_setting(self, goal_setting: GoalSetting) -> None:
        with self._engine.begin() as conn:
            conn.execute(
                update(goal_settings_table)
                .where(goal_settings_table.c.assignment_id == str(goal_setting.assignment_id))
                .values(**_goal_setting_values(goal_setting, include_id=False))
            )

    def get_goal_setting(self, assignment_id: UUID) -> Optional[GoalSetting]:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(goal_settings_table).where(
                    goal_settings_table.c.assignment_id == str(assignment_id)
                )
            ).mappings().first()
        if row is None:
            return None
        return _row_to_goal_setting(row)

    def get_closure_record(self, assignment_id: UUID) -> Optional[ClosureRecord]:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(closure_records_table).where(
                    closure_records_table.c.assignment_id == str(assignment_id)
                )
            ).mappings().first()
        if row is None:
            return None
        return ClosureRecord(
            id=UUID(row["id"]),
            assignment_id=UUID(row["assignment_id"]),
            objective_score=row["objective_score"],
            subjective_notes=row["subjective_notes"],
            recorded_at=row["recorded_at"],
        )

    # -- Review & Scoring (Phase 3) --

    def add_review_score(self, review_score: ReviewScore) -> None:
        with self._engine.begin() as conn:
            conn.execute(insert(review_scores_table).values(**_review_score_values(review_score)))

    def update_review_score(self, review_score: ReviewScore) -> None:
        with self._engine.begin() as conn:
            conn.execute(
                update(review_scores_table)
                .where(review_scores_table.c.assignment_id == str(review_score.assignment_id))
                .values(**_review_score_values(review_score, include_id=False))
            )

    def get_review_score(self, assignment_id: UUID) -> Optional[ReviewScore]:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(review_scores_table).where(
                    review_scores_table.c.assignment_id == str(assignment_id)
                )
            ).mappings().first()
        if row is None:
            return None
        return _row_to_review_score(row)

    # -- Extension/Closure requests (Phase 3) --

    def add_change_request(self, request: ChangeRequest) -> None:
        with self._engine.begin() as conn:
            conn.execute(insert(change_requests_table).values(**_change_request_values(request)))

    def update_change_request(self, request: ChangeRequest) -> None:
        with self._engine.begin() as conn:
            conn.execute(
                update(change_requests_table)
                .where(change_requests_table.c.id == str(request.id))
                .values(**_change_request_values(request, include_id=False))
            )

    def get_change_request(self, request_id: UUID) -> Optional[ChangeRequest]:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(change_requests_table).where(
                    change_requests_table.c.id == str(request_id)
                )
            ).mappings().first()
        return _row_to_change_request(row) if row is not None else None

    def list_change_requests(self, assignment_id: UUID) -> list[ChangeRequest]:
        with self._engine.connect() as conn:
            rows = conn.execute(
                select(change_requests_table).where(
                    change_requests_table.c.assignment_id == str(assignment_id)
                )
            ).mappings().all()
        return [_row_to_change_request(r) for r in rows]

    def list_pending_change_requests(self) -> list[ChangeRequest]:
        with self._engine.connect() as conn:
            rows = conn.execute(
                select(change_requests_table).where(
                    change_requests_table.c.status == RequestStatus.PENDING.value
                )
            ).mappings().all()
        return [_row_to_change_request(r) for r in rows]

    def add_reverse_feedback(self, feedback: ReverseFeedback) -> None:
        with self._engine.begin() as conn:
            conn.execute(
                insert(reverse_feedback_table).values(
                    id=str(feedback.id),
                    assignment_id=str(feedback.assignment_id),
                    notes=feedback.notes,
                    recorded_at=feedback.recorded_at,
                )
            )

    def list_reverse_feedback(self, assignment_id: UUID) -> list[ReverseFeedback]:
        with self._engine.connect() as conn:
            rows = conn.execute(
                select(reverse_feedback_table).where(
                    reverse_feedback_table.c.assignment_id == str(assignment_id)
                )
            ).mappings().all()
        return [
            ReverseFeedback(
                id=UUID(r["id"]),
                assignment_id=UUID(r["assignment_id"]),
                notes=r["notes"],
                recorded_at=r["recorded_at"],
            )
            for r in rows
        ]


def _assignment_values(
    assignment: Assignment, include_id: bool = True, bump_version: bool = False
) -> dict:
    values = {
        "agent_id": str(assignment.agent_id),
        "manager_id": str(assignment.manager_id),
        "start_date": assignment.start_date,
        "end_date": assignment.end_date,
        "state": assignment.state.value,
        "kind": assignment.kind.value,
        "closed_reason": assignment.closed_reason,
        "closure_note": assignment.closure_note,
        "version": assignment.version + 1 if bump_version else assignment.version,
        "created_at": assignment.created_at,
    }
    if include_id:
        values["id"] = str(assignment.id)
    return values


def _goal_setting_values(goal_setting: GoalSetting, include_id: bool = True) -> dict:
    values = {
        "assignment_id": str(goal_setting.assignment_id),
        "goals": goal_setting.goals,
        "criteria": goal_setting.criteria,
        "set_at": goal_setting.set_at,
        "frozen": int(goal_setting.frozen),
        "agreed_by": str(goal_setting.agreed_by) if goal_setting.agreed_by else None,
        "agreed_at": goal_setting.agreed_at,
    }
    if include_id:
        values["id"] = str(goal_setting.id)
    return values


def _row_to_goal_setting(row) -> GoalSetting:
    return GoalSetting(
        id=UUID(row["id"]),
        assignment_id=UUID(row["assignment_id"]),
        goals=row["goals"],
        criteria=list(row["criteria"] or []),
        set_at=row["set_at"],
        frozen=bool(row["frozen"]),
        agreed_by=UUID(row["agreed_by"]) if row["agreed_by"] else None,
        agreed_at=row["agreed_at"],
    )


def _review_score_values(review_score: ReviewScore, include_id: bool = True) -> dict:
    values = {
        "assignment_id": str(review_score.assignment_id),
        "criterion_scores": review_score.criterion_scores,
        "objective_score": review_score.objective_score,
        "notes": review_score.notes,
        "submitted_by": str(review_score.submitted_by) if review_score.submitted_by else None,
        "submitted_at": review_score.submitted_at,
        "frozen": int(review_score.frozen),
    }
    if include_id:
        values["id"] = str(review_score.id)
    return values


def _row_to_review_score(row) -> ReviewScore:
    return ReviewScore(
        id=UUID(row["id"]),
        assignment_id=UUID(row["assignment_id"]),
        criterion_scores=dict(row["criterion_scores"] or {}),
        objective_score=row["objective_score"],
        notes=row["notes"],
        submitted_by=UUID(row["submitted_by"]) if row["submitted_by"] else None,
        submitted_at=row["submitted_at"],
        frozen=bool(row["frozen"]),
    )


def _change_request_values(request: ChangeRequest, include_id: bool = True) -> dict:
    values = {
        "assignment_id": str(request.assignment_id),
        "request_type": request.request_type.value,
        "requested_by": str(request.requested_by),
        "new_end_date": request.new_end_date,
        "notes": request.notes,
        "status": request.status.value,
        "requested_at": request.requested_at,
        "decided_by": str(request.decided_by) if request.decided_by else None,
        "decided_at": request.decided_at,
    }
    if include_id:
        values["id"] = str(request.id)
    return values


def _row_to_change_request(row) -> ChangeRequest:
    return ChangeRequest(
        id=UUID(row["id"]),
        assignment_id=UUID(row["assignment_id"]),
        request_type=RequestType(row["request_type"]),
        requested_by=UUID(row["requested_by"]),
        new_end_date=row["new_end_date"],
        notes=row["notes"],
        status=RequestStatus(row["status"]),
        requested_at=row["requested_at"],
        decided_by=UUID(row["decided_by"]) if row["decided_by"] else None,
        decided_at=row["decided_at"],
    )


def _row_to_assignment(row) -> Assignment:
    return Assignment(
        id=UUID(row["id"]),
        agent_id=UUID(row["agent_id"]),
        manager_id=UUID(row["manager_id"]),
        start_date=row["start_date"],
        end_date=row["end_date"],
        state=AssignmentState(row["state"]),
        kind=AssignmentKind(row["kind"]),
        closed_reason=row["closed_reason"],
        closure_note=row["closure_note"],
        version=row["version"],
        created_at=row["created_at"],
    )
